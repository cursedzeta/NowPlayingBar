# overlay_ui.py
# Barra con controles (prev/play/next), sin volumen, atajos GLOBALS.

import time, threading, webbrowser
from PySide6 import QtCore, QtGui, QtWidgets

from config import (
    FAST_POLL_SECONDS, IDLE_POLL_SECONDS, PADDING_X, PADDING_Y, PAUSED_POLL_SECONDS, WIDTH, HEIGHT,
    STYLE_BG, STYLE_LABEL, STYLE_PROGRESS,
    POLL_SECONDS, MARQUEE_SPEED_MS,
    MARGIN_RIGHT, TASKBAR_GAP_PX,
    REMEMBER_POS, LOCK_POSITION_DEFAULT, DRAG_SNAP_PX
)
from icons import icon_play, icon_pause, icon_next, icon_prev
from hotkeys import HK_VOL_DOWN, HK_VOL_UP, register_hotkeys, unregister_hotkeys, HK_TOGGLE, HK_PREV, HK_NEXT
from settings_store import load_settings, save_settings



# ---------- Label con marquesina ----------
class MarqueeLabel(QtWidgets.QLabel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.offset = 0
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.setStyleSheet(STYLE_LABEL)
        self.setAlignment(QtCore.Qt.AlignVCenter | QtCore.Qt.AlignLeft)

    def start(self): self.timer.start(MARQUEE_SPEED_MS)
    def reset_scroll(self): self.offset = 0; self.update()

    def tick(self):
        self.offset += 1
        if self.offset > self.fontMetrics().horizontalAdvance(self.text()) + 40:
            self.offset = 0
        self.update()

    def paintEvent(self, e):
        p = QtGui.QPainter(self)
        txt = self.text()
        fm = self.fontMetrics()
        text_w = fm.horizontalAdvance(txt)
        h = self.height()
        x = -self.offset
        while x < self.width():
            p.drawText(x, 0, max(text_w + 40, self.width()), h,
                       QtCore.Qt.AlignVCenter | QtCore.Qt.AlignLeft, txt)
            x += text_w + 40


# ---------- Grip de arrastre ----------
class DragGrip(QtWidgets.QFrame):
    startDrag = QtCore.Signal(QtCore.QPointF)
    doDrag    = QtCore.Signal(QtCore.QPointF)
    endDrag   = QtCore.Signal()
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(12)
        self.setCursor(QtCore.Qt.SizeAllCursor)
        self.setStyleSheet("""
            QFrame {
                background: rgba(15,15,15,100);
                border-top-left-radius: 9px;
                border-bottom-left-radius: 9px;
            }
        """)
        self._dragging = False
    def mousePressEvent(self, e):
        if e.button() == QtCore.Qt.LeftButton:
            self._dragging = True; self.startDrag.emit(e.globalPosition()); e.accept()
        else: super().mousePressEvent(e)
    def mouseMoveEvent(self, e):
        if self._dragging:
            self.doDrag.emit(e.globalPosition()); e.accept()
        else: super().mouseMoveEvent(e)
    def mouseReleaseEvent(self, e):
        if self._dragging and e.button() == QtCore.Qt.LeftButton:
            self._dragging = False; self.endDrag.emit(); e.accept()
        else: super().mouseReleaseEvent(e)

# ---------- Ventana principal ----------
class Overlay(QtWidgets.QWidget):
    newText = QtCore.Signal(str)
    newProg = QtCore.Signal(int)
    newState = QtCore.Signal(bool)

    def __init__(self, spotify):
        super().__init__()
        self.sp = spotify
        self.playing = False
        self.pos_locked = LOCK_POSITION_DEFAULT
        self._drag_offset = QtCore.QPoint(0, 0)

        self.setWindowFlags(QtCore.Qt.FramelessWindowHint |
                            QtCore.Qt.WindowStaysOnTopHint |
                            QtCore.Qt.Tool)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        # Fondo + grip
        self.bg = QtWidgets.QFrame(); self.bg.setStyleSheet(STYLE_BG)
        self.grip = DragGrip(self)
        self.grip.startDrag.connect(self._on_start_drag)
        self.grip.doDrag.connect(self._on_do_drag)
        self.grip.endDrag.connect(self._on_end_drag)

        # Controles
        self.btnPrev = QtWidgets.QToolButton()
        self.btnPlay = QtWidgets.QToolButton()
        self.btnNext = QtWidgets.QToolButton()
        for b in (self.btnPrev, self.btnPlay, self.btnNext):
            b.setAutoRaise(True); b.setIconSize(QtCore.QSize(16, 16))
            b.setCursor(QtCore.Qt.PointingHandCursor)
        self.btnPrev.setIcon(icon_prev())
        self.btnPlay.setIcon(icon_play())
        self.btnNext.setIcon(icon_next())

        # Texto
        self.label = MarqueeLabel("Esperando reproducción…")
        self.label.setMinimumWidth(200)

        # Progreso
        self.progress = QtWidgets.QProgressBar()
        self.progress.setFixedHeight(2)
        self.progress.setTextVisible(False)
        self.progress.setRange(0, 1000)
        self.progress.setStyleSheet(STYLE_PROGRESS)

        # Layout
        top = QtWidgets.QHBoxLayout()
        top.setContentsMargins(PADDING_X, PADDING_Y, PADDING_X, 6)
        top.setSpacing(8)
        top.addWidget(self.grip)
        top.addWidget(self.btnPrev)
        top.addWidget(self.btnPlay)
        top.addWidget(self.btnNext)
        top.addSpacing(4)
        top.addWidget(self.label, 1)

        v = QtWidgets.QVBoxLayout(self.bg)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        v.addLayout(top)
        v.addWidget(self.progress)

        root = QtWidgets.QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(self.bg)

        self.resize(WIDTH, HEIGHT)
        self._restore_or_default_position()

        # Señales UI
        self.newText.connect(self.set_text)
        self.newProg.connect(self.progress.setValue)
        self.newState.connect(self.set_playing)

        # Worker Spotify
        self.worker = threading.Thread(target=self.loop_spotify, daemon=True)
        self.worker.start()

        self.label.start()
        self.smooth = QtCore.QTimer(self); self.smooth.setInterval(200)
        self.smooth.timeout.connect(self._tick_progress_local)
        self._progress_local = 0; self.smooth.start()

        # Interacciones
        self.bg.mouseDoubleClickEvent = self.open_spotify
        self.bg.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.bg.customContextMenuRequested.connect(self.show_menu)
        self.btnPrev.clicked.connect(self.on_prev)
        self.btnPlay.clicked.connect(self.on_toggle)
        self.btnNext.clicked.connect(self.on_next)

        # Atajos GLOBALS
        self._hotkeys = register_hotkeys(self, self.handle_hotkey)

    # ----- Posición / persistencia / magnetismo -----
    def position_bottom_right(self):
        screen = QtGui.QGuiApplication.screenAt(QtGui.QCursor.pos()) \
                 or QtGui.QGuiApplication.primaryScreen()
        avail = screen.availableGeometry()
        x = avail.right() - self.width() - MARGIN_RIGHT
        y = avail.bottom() - self.height() - TASKBAR_GAP_PX
        self.move(x, y)

    def _restore_or_default_position(self):
        if not REMEMBER_POS:
            self.position_bottom_right(); return
        s = load_settings()
        pos = s.get("window_pos")
        if isinstance(pos, list) and len(pos) == 2:
            self.move(self._snap_and_clamp(QtCore.QPoint(int(pos[0]), int(pos[1]))))
        else:
            self.position_bottom_right()
        self.pos_locked = bool(s.get("pos_locked", LOCK_POSITION_DEFAULT))

    def _save_position(self):
        if not REMEMBER_POS: return
        s = load_settings()
        s["window_pos"] = [int(self.x()), int(self.y())]
        s["pos_locked"] = bool(self.pos_locked)
        save_settings(s)

    def _on_start_drag(self, gpos):
        if self.pos_locked: return
        tl = self.frameGeometry().topLeft()
        self._drag_offset = QtCore.QPoint(int(gpos.x()) - tl.x(), int(gpos.y()) - tl.y())

    def _on_do_drag(self, gpos):
        if self.pos_locked: return
        desired = QtCore.QPoint(int(gpos.x()) - self._drag_offset.x(),
                                int(gpos.y()) - self._drag_offset.y())
        self.move(self._snap_and_clamp(desired))

    def _on_end_drag(self): self._save_position()

    def _snap_and_clamp(self, pt: QtCore.QPoint) -> QtCore.QPoint:
        screen = QtGui.QGuiApplication.screenAt(pt) or QtGui.QGuiApplication.primaryScreen()
        avail = screen.availableGeometry()
        x, y = pt.x(), pt.y(); w, h = self.width(), self.height()
        if abs(x - avail.left()) <= DRAG_SNAP_PX: x = avail.left()
        elif abs((x + w) - avail.right()) <= DRAG_SNAP_PX: x = avail.right() - w
        if abs(y - avail.top()) <= DRAG_SNAP_PX: y = avail.top()
        elif abs((y + h) - avail.bottom()) <= DRAG_SNAP_PX: y = avail.bottom() - h
        margin = 2
        x = max(avail.left()+margin, min(x, avail.right()-w-margin))
        y = max(avail.top()+margin,  min(y, avail.bottom()-h-margin))
        return QtCore.QPoint(x, y)

    # ----- Menú -----
    def show_menu(self, pos):
        menu = QtWidgets.QMenu(self)
        a1 = menu.addAction("Abrir Spotify")
        a2 = menu.addAction("Reubicar (abajo-derecha)")
        menu.addSeparator()
        a_lock = menu.addAction("Bloquear posición"); a_lock.setCheckable(True)
        a_lock.setChecked(self.pos_locked)
        menu.addSeparator()
        a3 = menu.addAction("Salir")

        act = menu.exec_(self.mapToGlobal(pos))
        if act == a1: self.open_spotify(None)
        elif act == a2: self.position_bottom_right(); self._save_position()
        elif act == a_lock: self.pos_locked = a_lock.isChecked(); self._save_position()
        elif act == a3: QtWidgets.QApplication.quit()

    # ----- UI -----
    def set_text(self, txt):
        if self.label.text() != txt:
            self.label.setText(txt); self.label.reset_scroll()

    def set_playing(self, is_playing):
        self.playing = is_playing
        self.btnPlay.setIcon(icon_pause() if is_playing else icon_play())

    def _tick_progress_local(self):
        if self.playing:
            self.progress.setValue(min(1000, self.progress.value() + 3))

    # ----- Hotkeys (globales) -----
    def handle_hotkey(self, hk_id):
        if hk_id == HK_TOGGLE:
            self.on_toggle()
        elif hk_id == HK_PREV:
            self.on_prev()
        elif hk_id == HK_NEXT:
            self.on_next()
        elif hk_id == HK_VOL_UP:
            self.adjust_volume(+5)
        elif hk_id == HK_VOL_DOWN:
            self.adjust_volume(-5)


    # ----- Spotify -----
    def on_prev(self):
        try: self.sp.previous_track()
        except Exception: pass
    def on_toggle(self):
        try:
            if self.playing: self.sp.pause_playback()
            else:            self.sp.start_playback()
        except Exception: pass
    def on_next(self):
        try: self.sp.next_track()
        except Exception: pass

    def adjust_volume(self, delta):
        """Sube o baja el volumen actual en pasos de 5%."""
        try:
            pb = self.sp.current_playback()
            if not pb or "device" not in pb:
                return
            vol = pb["device"].get("volume_percent", 50)
            new_vol = max(0, min(100, vol + delta))
            self.sp.volume(new_vol)
        except Exception:
            pass


    def loop_spotify(self):
        last_txt = None

        # por si querés recordar si viene de playing → paused
        is_playing_prev = False

        while True:
            sleep_s = IDLE_POLL_SECONDS  # valor por defecto
            try:
                pb = self.sp.current_playback()
                is_playing = False
                txt = "Nada reproduciéndose"
                pct = 0

                if pb:
                    if pb.get("item"):
                        name = pb["item"]["name"]
                        artists = ", ".join(a["name"] for a in pb["item"]["artists"])
                        txt = f"{name} — {artists}"
                        pos = int(pb.get("progress_ms") or 0)
                        dur = int(pb["item"].get("duration_ms") or 1)
                        pct = int(1000 * pos / max(1, dur))
                    is_playing = bool(pb.get("is_playing"))

                # Emit UI
                if txt != last_txt:
                    self.newText.emit(txt)
                    last_txt = txt

                self.newState.emit(is_playing)
                self.newProg.emit(pct)
                self._progress_local = pct

                # Poll adaptativo
                if is_playing:
                    sleep_s = FAST_POLL_SECONDS
                else:
                    # si veníamos reproduciendo y ahora se pausó, esperá un poco más
                    sleep_s = PAUSED_POLL_SECONDS

                is_playing_prev = is_playing

            except Exception as e:
                # Spotipy usa requests; si hay 429 rate limit, honor Retry-After
                retry_after = None
                try:
                    # SpotifyException tiene headers con Retry-After
                    if hasattr(e, "http_status") and e.http_status == 429:
                        retry_after = float(getattr(e, "headers", {}).get("Retry-After", ""))
                except Exception:
                    pass

                if retry_after:
                    sleep_s = max(retry_after, IDLE_POLL_SECONDS)
                else:
                    # caída de red o cualquier otro error
                    self.newText.emit("(sin conexión)")
                    self.newState.emit(False)
                    self.newProg.emit(0)
                    sleep_s = IDLE_POLL_SECONDS

            time.sleep(sleep_s)
    

    def open_spotify(self, event): webbrowser.open("https://open.spotify.com/")
    def closeEvent(self, e):
        self._save_position()
        unregister_hotkeys(self)
        e.accept()
